# Meios de comunicação

| Canal | Função |
|--------|--------|
| /911 | Comunicação com cidadãos (multas, denúncias, chamados). |
| /112 | Comunicação com serviços médicos em emergências. |
| Rádio policial | Comunicação operacional entre unidades e centrais. |
| Chat Polícia (CP) | Comunicação administrativa e situacional interna. |

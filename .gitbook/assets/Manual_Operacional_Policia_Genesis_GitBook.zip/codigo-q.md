# Código Q

Tabela de códigos Q mais utilizados no dia a dia operacional:

| Código | Significado |
|--------|-------------|
| QAP | Na escuta |
| QTC | Mensagem |
| QRR | Apoio terrestre |
| PTR | Patrulha |
| QRU | Ocorrência |
| VTR | Viatura |
| QSL | Compreendido |
| QTX | Saindo de serviço |
| QSM | Repetir mensagem |
| QRA | Nome e patente |
| QTA | Cancelar mensagem |
| QTO | Banheiro |
| TKS | Obrigado |
| QRL | Ocupado |
| QRX | Cessar comunicação |
| QSJ | Dinheiro |
| QTI | A caminho |
| QRV | Às suas ordens |
| QTH | Localização |
| QRT | Policial ferido |

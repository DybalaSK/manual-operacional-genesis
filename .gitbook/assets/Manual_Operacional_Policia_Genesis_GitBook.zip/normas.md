# Normas para uso da rádio e chat

A comunicação via rádio e chat deve seguir padrões estabelecidos para manter a ordem e eficiência do serviço.

## Rádio
- Verifique se o canal está livre antes de modular.
- Evite interrupções desnecessárias.
- Utilize linguagem objetiva e respeitosa.
- Mantenha o foco no assunto da ocorrência.

## Chat Polícia (CP)
- Informar entrada e saída de serviço (QTO / QTX).
- Comunicação de patrulha (Código 0).
- Relato de ocorrências e pedidos de reforço.
- Evite uso indevido para conversas informais.

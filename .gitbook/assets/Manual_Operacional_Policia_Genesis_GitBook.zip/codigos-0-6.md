# Códigos 0‑6

Códigos operacionais de situação e resposta:

| Código | Situação | Exemplo |
|--------|----------|----------|
| 0 | Em patrulha / retorno | Início de serviço |
| 1 | Ocorrência de baixa intensidade | Abordagem de trânsito |
| 2 | Ocorrência de média intensidade | Corrida ilegal, procurado |
| 3 | Alta intensidade | Sequestro, disparos |
| 4 | Sob controle / área limpa | Ocorrência concluída |
| 5 | Fogo aberto | Disparos contra guarnição |
| 6 | Equipe no local | Investigando local |

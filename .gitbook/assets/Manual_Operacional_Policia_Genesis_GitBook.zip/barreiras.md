# Barreiras no processo de comunicação

Embora pareça simples, a comunicação encontra diversas barreiras que podem interferir na clareza das mensagens transmitidas.

## Barreiras Individuais
- Falta de atenção ou concentração.
- Medo de errar ao modular.
- Dificuldade em compreender códigos e protocolos.

## Barreiras Organizacionais
- Ruído no rádio ou falhas técnicas.
- Interrupção de comunicações em andamento.
- Uso incorreto dos canais de rádio.

**Dica:** mantenha sempre a calma e a clareza, mesmo em situações de estresse.

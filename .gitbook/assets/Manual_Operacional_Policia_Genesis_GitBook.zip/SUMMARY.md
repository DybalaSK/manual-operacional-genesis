# Sumário

* [Introdução](README.md)
* [Comunicação Operacional](comunicacao-operacional.md)
  * [Barreiras no processo de comunicação](barreiras.md)
  * [Normas para uso da rádio e chat](normas.md)
  * [Meios de comunicação](meios.md)
  * [Código Q](codigo-q.md)
  * [Códigos 0‑6](codigos-0-6.md)
